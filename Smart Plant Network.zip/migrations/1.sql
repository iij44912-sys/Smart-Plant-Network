
CREATE TABLE plants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  species TEXT,
  location TEXT,
  image_url TEXT,
  care_instructions TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE sensor_readings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  plant_id INTEGER NOT NULL,
  soil_moisture REAL,
  temperature REAL,
  light_intensity REAL,
  air_quality REAL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE care_actions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  plant_id INTEGER NOT NULL,
  user_id TEXT NOT NULL,
  action_type TEXT NOT NULL, -- 'watered', 'fertilized', 'pruned', 'moved'
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE ai_recommendations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  plant_id INTEGER NOT NULL,
  recommendation_type TEXT NOT NULL, -- 'watering', 'lighting', 'temperature', 'fertilizing'
  message TEXT NOT NULL,
  priority TEXT NOT NULL, -- 'low', 'medium', 'high', 'urgent'
  is_acknowledged BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_plants_user_id ON plants(user_id);
CREATE INDEX idx_sensor_readings_plant_id ON sensor_readings(plant_id);
CREATE INDEX idx_sensor_readings_created_at ON sensor_readings(created_at);
CREATE INDEX idx_care_actions_plant_id ON care_actions(plant_id);
CREATE INDEX idx_care_actions_user_id ON care_actions(user_id);
CREATE INDEX idx_ai_recommendations_plant_id ON ai_recommendations(plant_id);
CREATE INDEX idx_ai_recommendations_acknowledged ON ai_recommendations(is_acknowledged);
