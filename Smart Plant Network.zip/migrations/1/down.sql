
DROP INDEX idx_ai_recommendations_acknowledged;
DROP INDEX idx_ai_recommendations_plant_id;
DROP INDEX idx_care_actions_user_id;
DROP INDEX idx_care_actions_plant_id;
DROP INDEX idx_sensor_readings_created_at;
DROP INDEX idx_sensor_readings_plant_id;
DROP INDEX idx_plants_user_id;
DROP TABLE ai_recommendations;
DROP TABLE care_actions;
DROP TABLE sensor_readings;
DROP TABLE plants;
