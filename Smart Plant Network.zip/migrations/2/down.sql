
DROP INDEX idx_plant_growth_plant_id;
DROP INDEX idx_plant_images_plant_id;
DROP TABLE plant_growth_analysis;
DROP TABLE plant_images;
