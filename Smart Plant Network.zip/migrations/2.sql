
CREATE TABLE plant_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  plant_id INTEGER NOT NULL,
  user_id TEXT NOT NULL,
  image_url TEXT NOT NULL,
  image_type TEXT NOT NULL, -- 'progress', 'care', 'general'
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE plant_growth_analysis (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  plant_id INTEGER NOT NULL,
  analysis_date DATE NOT NULL,
  growth_stage TEXT, -- 'seedling', 'young', 'mature', 'flowering'
  health_score REAL, -- 0-100
  growth_rate REAL, -- cm per week
  recommendations TEXT,
  ai_analysis TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_plant_images_plant_id ON plant_images(plant_id);
CREATE INDEX idx_plant_growth_plant_id ON plant_growth_analysis(plant_id);
