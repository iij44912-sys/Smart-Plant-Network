import { useEffect } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { useNavigate } from "react-router";
import { Leaf, Droplets, Sun, Brain, ArrowRight, Zap, Shield, Clock, Languages } from "lucide-react";
import { useTranslation } from "@/react-app/hooks/useTranslation";

export default function Home() {
  const { user, isPending, redirectToLogin } = useAuth();
  const navigate = useNavigate();
  const { t, toggleLanguage, language } = useTranslation();

  useEffect(() => {
    if (!isPending && user) {
      navigate("/dashboard");
    }
  }, [user, isPending, navigate]);

  const handleSignIn = async () => {
    await redirectToLogin();
  };

  if (isPending) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-cyan-50">
        <div className="animate-spin">
          <Leaf className="w-10 h-10 text-purple-600" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-cyan-50">
      {/* Header */}
      <header className="glass border-b border-purple-200/50 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center animate-pulse-glow">
                <Leaf className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gradient-primary">
                {t('app.title')}
              </h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <button
                onClick={toggleLanguage}
                className="flex items-center space-x-2 px-3 py-2 text-purple-600 hover:text-purple-700 transition-colors rounded-lg hover:bg-purple-100/50"
              >
                <Languages className="w-4 h-4" />
                <span className="text-sm font-medium">{t('language.switch')}</span>
              </button>
              
              <button
                onClick={handleSignIn}
                className="btn-primary"
              >
                {t('header.signIn')}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-400/20 via-pink-400/20 to-cyan-400/20 animate-float"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center">
            <div className="mb-8 flex justify-center">
              <div className="w-24 h-24 bg-gradient-primary rounded-3xl flex items-center justify-center shadow-2xl animate-pulse-glow">
                <Leaf className="w-14 h-14 text-white" />
              </div>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              {t('home.hero.title')}
              <span className="block text-gradient-primary">
                {t('home.hero.subtitle')}
              </span>
            </h1>
            
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              {t('home.hero.description')}
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={handleSignIn}
                className="btn-primary text-lg hover-lift"
              >
                {t('home.cta.getStarted')}
                <ArrowRight className={`w-5 h-5 ${language === 'ar' ? 'mr-2 rtl-flip' : 'ml-2'}`} />
              </button>
              
              <button className="btn-secondary text-lg hover-lift">
                {t('home.cta.watchDemo')}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 glass-dark">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              {t('home.features.title')}
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              {t('home.features.subtitle')}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="card hover-lift">
              <div className="w-12 h-12 bg-gradient-accent rounded-2xl flex items-center justify-center mb-6">
                <Droplets className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{t('home.features.watering.title')}</h3>
              <p className="text-gray-600">
                {t('home.features.watering.desc')}
              </p>
            </div>

            <div className="card hover-lift">
              <div className="w-12 h-12 bg-gradient-warning rounded-2xl flex items-center justify-center mb-6">
                <Sun className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{t('home.features.lighting.title')}</h3>
              <p className="text-gray-600">
                {t('home.features.lighting.desc')}
              </p>
            </div>

            <div className="card hover-lift">
              <div className="w-12 h-12 bg-gradient-primary rounded-2xl flex items-center justify-center mb-6">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{t('home.features.ai.title')}</h3>
              <p className="text-gray-600">
                {t('home.features.ai.desc')}
              </p>
            </div>

            <div className="card hover-lift">
              <div className="w-12 h-12 bg-gradient-success rounded-2xl flex items-center justify-center mb-6">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{t('home.features.alerts.title')}</h3>
              <p className="text-gray-600">
                {t('home.features.alerts.desc')}
              </p>
            </div>

            <div className="card hover-lift">
              <div className="w-12 h-12 bg-gradient-secondary rounded-2xl flex items-center justify-center mb-6">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{t('home.features.health.title')}</h3>
              <p className="text-gray-600">
                {t('home.features.health.desc')}
              </p>
            </div>

            <div className="card hover-lift">
              <div className="w-12 h-12 bg-gradient-accent rounded-2xl flex items-center justify-center mb-6">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{t('home.features.scheduling.title')}</h3>
              <p className="text-gray-600">
                {t('home.features.scheduling.desc')}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-gradient-primary rounded-3xl p-12 text-white shadow-2xl hover-lift">
            <h2 className="text-4xl font-bold mb-4">
              {t('home.final.title')}
            </h2>
            <p className="text-xl mb-8 opacity-90">
              {t('home.final.subtitle')}
            </p>
            <button
              onClick={handleSignIn}
              className="inline-flex items-center px-8 py-4 bg-white text-purple-600 font-semibold rounded-2xl hover:bg-gray-50 transition-all duration-200 shadow-lg hover:shadow-xl text-lg hover-lift"
            >
              {t('home.cta.getStarted')}
              <ArrowRight className={`w-5 h-5 ${language === 'ar' ? 'mr-2 rtl-flip' : 'ml-2'}`} />
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="glass border-t border-purple-200/50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center">
            <div className="flex items-center space-x-3">
              <div className="w-6 h-6 bg-gradient-primary rounded-lg flex items-center justify-center">
                <Leaf className="w-4 h-4 text-white" />
              </div>
              <span className="text-gray-600">{t('home.footer')}</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
