import { useEffect, useState } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { useNavigate } from "react-router";
import { Plus, Bell, Droplets, Sun, Leaf, Languages } from "lucide-react";
import type { PlantWithSensorData } from "@/shared/types";
import PlantCard from "@/react-app/components/PlantCard";
import AddPlantModal from "@/react-app/components/AddPlantModal";
import NotificationPanel from "@/react-app/components/NotificationPanel";
import { useTranslation } from "@/react-app/hooks/useTranslation";

export default function Dashboard() {
  const { user, isPending, logout } = useAuth();
  const navigate = useNavigate();
  const { t, toggleLanguage, language } = useTranslation();
  const [plants, setPlants] = useState<PlantWithSensorData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showAddPlant, setShowAddPlant] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    if (!isPending && !user) {
      navigate("/");
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      fetchPlants();
    }
  }, [user]);

  const fetchPlants = async () => {
    try {
      const response = await fetch("/api/plants", {
        credentials: "include",
      });
      if (response.ok) {
        const data = await response.json();
        setPlants(data);
      }
    } catch (error) {
      console.error("Failed to fetch plants:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddPlant = () => {
    setShowAddPlant(false);
    fetchPlants();
  };

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  const allRecommendations = plants.flatMap(plant => 
    plant.recommendations?.map(rec => ({ ...rec, plantName: plant.name })) || []
  );

  const urgentCount = allRecommendations.filter(rec => rec.priority === 'urgent').length;

  if (isPending || isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-cyan-50">
        <div className="animate-spin">
          <Leaf className="w-10 h-10 text-purple-600" />
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-cyan-50">
      {/* Header */}
      <header className="glass border-b border-purple-200/50 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center animate-pulse-glow">
                <Leaf className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gradient-primary">
                {t('app.title')}
              </h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <button
                onClick={toggleLanguage}
                className="flex items-center space-x-2 px-3 py-2 text-purple-600 hover:text-purple-700 transition-colors rounded-lg hover:bg-purple-100/50"
              >
                <Languages className="w-4 h-4" />
                <span className="text-sm font-medium">{t('language.switch')}</span>
              </button>
              
              <button
                onClick={() => setShowNotifications(true)}
                className="relative p-2 text-purple-600 hover:text-purple-700 transition-colors"
              >
                <Bell className="w-5 h-5" />
                {urgentCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-gradient-secondary text-white text-xs rounded-full w-5 h-5 flex items-center justify-center animate-pulse">
                    {urgentCount}
                  </span>
                )}
              </button>
              
              <div className="flex items-center space-x-3">
                <img
                  src={user.google_user_data.picture || ''}
                  alt={user.google_user_data.name || ''}
                  className="w-8 h-8 rounded-full ring-2 ring-purple-200"
                />
                <button
                  onClick={handleLogout}
                  className="text-sm text-purple-600 hover:text-purple-700 transition-colors"
                >
                  {t('header.signOut')}
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            {t('dashboard.welcome')}, {user.google_user_data.given_name || 'Plant Parent'}! 🌱
          </h2>
          <p className="text-gray-600">
            {t('dashboard.subtitle')}
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="card hover-lift">
            <div className="flex items-center">
              <div className="p-2 bg-gradient-primary rounded-lg">
                <Leaf className="w-6 h-6 text-white" />
              </div>
              <div className={`${language === 'ar' ? 'mr-4' : 'ml-4'}`}>
                <p className="text-sm font-medium text-gray-600">{t('dashboard.stats.totalPlants')}</p>
                <p className="text-2xl font-bold text-gray-900">{plants.length}</p>
              </div>
            </div>
          </div>

          <div className="card hover-lift">
            <div className="flex items-center">
              <div className="p-2 bg-gradient-accent rounded-lg">
                <Droplets className="w-6 h-6 text-white" />
              </div>
              <div className={`${language === 'ar' ? 'mr-4' : 'ml-4'}`}>
                <p className="text-sm font-medium text-gray-600">{t('dashboard.stats.needWater')}</p>
                <p className="text-2xl font-bold text-gray-900">
                  {plants.filter(p => p.recommendations?.some(r => r.recommendation_type === 'watering')).length}
                </p>
              </div>
            </div>
          </div>

          <div className="card hover-lift">
            <div className="flex items-center">
              <div className="p-2 bg-gradient-warning rounded-lg">
                <Sun className="w-6 h-6 text-white" />
              </div>
              <div className={`${language === 'ar' ? 'mr-4' : 'ml-4'}`}>
                <p className="text-sm font-medium text-gray-600">{t('dashboard.stats.needLight')}</p>
                <p className="text-2xl font-bold text-gray-900">
                  {plants.filter(p => p.recommendations?.some(r => r.recommendation_type === 'lighting')).length}
                </p>
              </div>
            </div>
          </div>

          <div className="card hover-lift">
            <div className="flex items-center">
              <div className="p-2 bg-gradient-secondary rounded-lg">
                <Bell className="w-6 h-6 text-white" />
              </div>
              <div className={`${language === 'ar' ? 'mr-4' : 'ml-4'}`}>
                <p className="text-sm font-medium text-gray-600">{t('dashboard.stats.urgent')}</p>
                <p className="text-2xl font-bold text-gray-900">{urgentCount}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Plants Section */}
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold text-gray-900">{t('dashboard.yourPlants')}</h3>
          <button
            onClick={() => setShowAddPlant(true)}
            className="btn-primary hover-lift"
          >
            <Plus className={`w-5 h-5 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
            {t('dashboard.addPlant')}
          </button>
        </div>

        {plants.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {plants.map((plant) => (
              <PlantCard key={plant.id} plant={plant} onUpdate={fetchPlants} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse-glow">
              <Leaf className="w-12 h-12 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">{t('dashboard.noPlants.title')}</h3>
            <p className="text-gray-600 mb-6">{t('dashboard.noPlants.subtitle')}</p>
            <button
              onClick={() => setShowAddPlant(true)}
              className="btn-primary hover-lift"
            >
              <Plus className={`w-5 h-5 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
              {t('dashboard.noPlants.cta')}
            </button>
          </div>
        )}
      </main>

      {/* Modals */}
      {showAddPlant && (
        <AddPlantModal onClose={() => setShowAddPlant(false)} onSuccess={handleAddPlant} />
      )}

      {showNotifications && (
        <NotificationPanel
          recommendations={allRecommendations}
          onClose={() => setShowNotifications(false)}
          onUpdate={fetchPlants}
        />
      )}
    </div>
  );
}
