import { createContext, useContext, useState, ReactNode } from 'react';

interface Translations {
  [key: string]: string;
}

const englishTranslations: Translations = {
  // Header
  'app.title': 'Smart Plant Network',
  'header.signIn': 'Sign In with Google',
  'header.signOut': 'Sign Out',
  
  // Home page
  'home.hero.title': 'AI-Powered Plant Care',
  'home.hero.subtitle': 'Made Simple',
  'home.hero.description': 'Monitor your plants\' health in real-time with smart sensors and get personalized AI recommendations for watering, lighting, and care. Perfect for plant lovers, busy professionals, and green spaces.',
  'home.cta.getStarted': 'Get Started Free',
  'home.cta.watchDemo': 'Watch Demo',
  'home.features.title': 'Everything Your Plants Need',
  'home.features.subtitle': 'Comprehensive monitoring and intelligent care recommendations powered by AI',
  'home.features.watering.title': 'Smart Watering',
  'home.features.watering.desc': 'Get precise watering recommendations based on soil moisture, plant type, and weather conditions.',
  'home.features.lighting.title': 'Light Optimization',
  'home.features.lighting.desc': 'Monitor light intensity and get suggestions for optimal plant placement throughout your space.',
  'home.features.ai.title': 'AI Insights',
  'home.features.ai.desc': 'Learn from your care habits and get personalized recommendations that improve over time.',
  'home.features.alerts.title': 'Real-time Alerts',
  'home.features.alerts.desc': 'Receive instant notifications when your plants need attention, preventing problems before they start.',
  'home.features.health.title': 'Health Monitoring',
  'home.features.health.desc': 'Track temperature, humidity, and air quality to ensure optimal growing conditions.',
  'home.features.scheduling.title': 'Automated Scheduling',
  'home.features.scheduling.desc': 'Set up smart care schedules that adapt to seasons, weather, and your plant\'s growth cycle.',
  'home.final.title': 'Start Growing Smarter Today',
  'home.final.subtitle': 'Join thousands of plant parents who trust Smart Plant Network to keep their plants healthy and thriving.',
  'home.footer': '© 2024 Smart Plant Network. Made with 💚 for plant lovers.',
  
  // Dashboard
  'dashboard.welcome': 'Welcome back',
  'dashboard.subtitle': 'Monitor your plants and get AI-powered care recommendations',
  'dashboard.stats.totalPlants': 'Total Plants',
  'dashboard.stats.needWater': 'Need Water',
  'dashboard.stats.needLight': 'Need Light',
  'dashboard.stats.urgent': 'Urgent',
  'dashboard.yourPlants': 'Your Plants',
  'dashboard.addPlant': 'Add Plant',
  'dashboard.noPlants.title': 'No plants yet',
  'dashboard.noPlants.subtitle': 'Add your first plant to start monitoring its health!',
  'dashboard.noPlants.cta': 'Add Your First Plant',
  
  // Plant Card
  'plant.healthy': 'Healthy',
  'plant.needsCare': 'Needs Care',
  'plant.needsAttention': 'Needs Immediate Attention',
  'plant.soilMoisture': 'Soil Moisture',
  'plant.light': 'Light',
  'plant.temperature': 'Temperature',
  'plant.airQuality': 'Air Quality',
  'plant.noData': 'No sensor data available',
  'plant.generateData': 'Generate Sample Data',
  'plant.generating': 'Generating...',
  'plant.recommendations': 'AI Recommendations',
  'plant.watered': 'Watered',
  'plant.update': 'Update',
  'plant.lastUpdated': 'Last updated',
  
  // Add Plant Modal
  'addPlant.title': 'Add New Plant',
  'addPlant.popularPlants': 'Popular Plants',
  'addPlant.name': 'Plant Name',
  'addPlant.nameRequired': '(Required)',
  'addPlant.namePlaceholder': 'e.g., My Snake Plant',
  'addPlant.species': 'Species (Optional)',
  'addPlant.speciesPlaceholder': 'e.g., Sansevieria trifasciata',
  'addPlant.location': 'Location (Optional)',
  'addPlant.locationPlaceholder': 'e.g., Living room, Office desk',
  'addPlant.photo': 'Plant Photo (Optional)',
  'addPlant.photoPlaceholder': 'https://example.com/plant-photo.jpg',
  'addPlant.sampleImages': 'Or choose a sample image:',
  'addPlant.careInstructions': 'Care Instructions (Optional)',
  'addPlant.carePlaceholder': 'e.g., Water weekly, prefers indirect sunlight...',
  'addPlant.cancel': 'Cancel',
  'addPlant.adding': 'Adding...',
  'addPlant.add': 'Add Plant',
  
  // Notifications
  'notifications.title': 'Plant Notifications',
  'notifications.count': 'recommendation',
  'notifications.countPlural': 'recommendations',
  'notifications.allCaughtUp': 'All caught up!',
  'notifications.noCare': 'Your plants are happy and healthy. No urgent care needed right now.',
  'notifications.priority.urgent': 'Urgent Priority',
  'notifications.priority.high': 'High Priority',
  'notifications.priority.medium': 'Medium Priority',
  'notifications.priority.low': 'Low Priority',
  'notifications.markDone': 'Mark as Done',
  'notifications.acknowledging': 'Acknowledging...',
  'notifications.footer': 'Keep your plants healthy by following these AI-powered recommendations.',
  'notifications.close': 'Close',
  
  // Language
  'language.switch': 'العربية',
  
  // Image Upload
  'imageUpload.invalidType': 'Please select a valid image file',
  'imageUpload.sizeTooLarge': 'Image size must be less than 10MB',
  'imageUpload.uploadFailed': 'Failed to upload image. Please try again.',
  'imageUpload.change': 'Change',
  'imageUpload.remove': 'Remove',
  'imageUpload.uploading': 'Uploading...',
  'imageUpload.clickToUpload': 'Click to upload image',
  'imageUpload.dragDrop': 'or drag and drop',
  'imageUpload.fileTypes': 'PNG, JPG, GIF up to 10MB',
  
  // Plant Search
  'plantSearch.searching': 'Searching...',
  'plantSearch.found': 'Plant information found!',
  'plantSearch.notFound': 'Plant information not found',
  'plantSearch.error': 'Search failed. Please try again.',
  'plantSearch.autoFill': 'Auto-fill plant information',
  
  // Growth Tracking
  'growth.title': 'Growth Tracking',
  'growth.uploadProgress': 'Upload Progress Photo',
  'growth.viewHistory': 'View Growth History',
  'growth.analysis': 'AI Growth Analysis',
  'growth.stage': 'Growth Stage',
  'growth.healthScore': 'Health Score',
  'growth.growthRate': 'Growth Rate',
  'growth.recommendations': 'Growth Recommendations',
};

const arabicTranslations: Translations = {
  // Header
  'app.title': 'شبكة النباتات الذكية',
  'header.signIn': 'تسجيل الدخول بجوجل',
  'header.signOut': 'تسجيل الخروج',
  
  // Home page
  'home.hero.title': 'رعاية النباتات بالذكاء الاصطناعي',
  'home.hero.subtitle': 'بطريقة بسيطة',
  'home.hero.description': 'راقب صحة نباتاتك في الوقت الفعلي باستخدام أجهزة الاستشعار الذكية واحصل على توصيات شخصية مدعومة بالذكاء الاصطناعي للري والإضاءة والرعاية. مثالي لمحبي النباتات والمهنيين المشغولين والمساحات الخضراء.',
  'home.cta.getStarted': 'ابدأ مجاناً',
  'home.cta.watchDemo': 'شاهد العرض التوضيحي',
  'home.features.title': 'كل ما تحتاجه نباتاتك',
  'home.features.subtitle': 'مراقبة شاملة وتوصيات رعاية ذكية مدعومة بالذكاء الاصطناعي',
  'home.features.watering.title': 'الري الذكي',
  'home.features.watering.desc': 'احصل على توصيات دقيقة للري بناءً على رطوبة التربة ونوع النبات وظروف الطقس.',
  'home.features.lighting.title': 'تحسين الإضاءة',
  'home.features.lighting.desc': 'راقب شدة الإضاءة واحصل على اقتراحات لوضع النباتات بشكل مثالي في مساحتك.',
  'home.features.ai.title': 'رؤى الذكاء الاصطناعي',
  'home.features.ai.desc': 'تعلم من عادات الرعاية الخاصة بك واحصل على توصيات شخصية تتحسن مع الوقت.',
  'home.features.alerts.title': 'تنبيهات فورية',
  'home.features.alerts.desc': 'احصل على إشعارات فورية عندما تحتاج نباتاتك للعناية، مما يمنع المشاكل قبل حدوثها.',
  'home.features.health.title': 'مراقبة الصحة',
  'home.features.health.desc': 'تتبع درجة الحرارة والرطوبة وجودة الهواء لضمان ظروف نمو مثالية.',
  'home.features.scheduling.title': 'الجدولة التلقائية',
  'home.features.scheduling.desc': 'إعداد جداول رعاية ذكية تتكيف مع المواسم والطقس ودورة نمو النبات.',
  'home.final.title': 'ابدأ بالنمو الذكي اليوم',
  'home.final.subtitle': 'انضم إلى آلاف محبي النباتات الذين يثقون في شبكة النباتات الذكية للحفاظ على صحة نباتاتهم وازدهارها.',
  'home.footer': '© 2024 شبكة النباتات الذكية. صُنع بـ 💚 لمحبي النباتات.',
  
  // Dashboard
  'dashboard.welcome': 'مرحباً بعودتك',
  'dashboard.subtitle': 'راقب نباتاتك واحصل على توصيات مدعومة بالذكاء الاصطناعي',
  'dashboard.stats.totalPlants': 'إجمالي النباتات',
  'dashboard.stats.needWater': 'تحتاج ماء',
  'dashboard.stats.needLight': 'تحتاج ضوء',
  'dashboard.stats.urgent': 'عاجل',
  'dashboard.yourPlants': 'نباتاتك',
  'dashboard.addPlant': 'إضافة نبات',
  'dashboard.noPlants.title': 'لا توجد نباتات بعد',
  'dashboard.noPlants.subtitle': 'أضف نباتك الأول لبدء مراقبة صحته!',
  'dashboard.noPlants.cta': 'أضف نباتك الأول',
  
  // Plant Card
  'plant.healthy': 'صحي',
  'plant.needsCare': 'يحتاج رعاية',
  'plant.needsAttention': 'يحتاج عناية فورية',
  'plant.soilMoisture': 'رطوبة التربة',
  'plant.light': 'الضوء',
  'plant.temperature': 'درجة الحرارة',
  'plant.airQuality': 'جودة الهواء',
  'plant.noData': 'لا توجد بيانات من أجهزة الاستشعار',
  'plant.generateData': 'إنشاء بيانات عينة',
  'plant.generating': 'جاري الإنشاء...',
  'plant.recommendations': 'توصيات الذكاء الاصطناعي',
  'plant.watered': 'تم الري',
  'plant.update': 'تحديث',
  'plant.lastUpdated': 'آخر تحديث',
  
  // Add Plant Modal
  'addPlant.title': 'إضافة نبات جديد',
  'addPlant.popularPlants': 'النباتات الشائعة',
  'addPlant.name': 'اسم النبات',
  'addPlant.nameRequired': '(مطلوب)',
  'addPlant.namePlaceholder': 'مثال: نبات الثعبان الخاص بي',
  'addPlant.species': 'النوع (اختياري)',
  'addPlant.speciesPlaceholder': 'مثال: Sansevieria trifasciata',
  'addPlant.location': 'الموقع (اختياري)',
  'addPlant.locationPlaceholder': 'مثال: غرفة المعيشة، مكتب العمل',
  'addPlant.photo': 'صورة النبات (اختياري)',
  'addPlant.photoPlaceholder': 'https://example.com/plant-photo.jpg',
  'addPlant.sampleImages': 'أو اختر صورة عينة:',
  'addPlant.careInstructions': 'تعليمات الرعاية (اختياري)',
  'addPlant.carePlaceholder': 'مثال: الري أسبوعياً، يفضل الضوء غير المباشر...',
  'addPlant.cancel': 'إلغاء',
  'addPlant.adding': 'جاري الإضافة...',
  'addPlant.add': 'إضافة النبات',
  
  // Notifications
  'notifications.title': 'إشعارات النباتات',
  'notifications.count': 'توصية',
  'notifications.countPlural': 'توصيات',
  'notifications.allCaughtUp': 'كل شيء محدث!',
  'notifications.noCare': 'نباتاتك سعيدة وصحية. لا حاجة لرعاية عاجلة الآن.',
  'notifications.priority.urgent': 'أولوية عاجلة',
  'notifications.priority.high': 'أولوية عالية',
  'notifications.priority.medium': 'أولوية متوسطة',
  'notifications.priority.low': 'أولوية منخفضة',
  'notifications.markDone': 'تحديد كمنجز',
  'notifications.acknowledging': 'جاري التأكيد...',
  'notifications.footer': 'حافظ على صحة نباتاتك باتباع هذه التوصيات المدعومة بالذكاء الاصطناعي.',
  'notifications.close': 'إغلاق',
  
  // Language
  'language.switch': 'English',
  
  // Image Upload
  'imageUpload.invalidType': 'يرجى اختيار ملف صورة صالح',
  'imageUpload.sizeTooLarge': 'يجب أن يكون حجم الصورة أقل من 10 ميجابايت',
  'imageUpload.uploadFailed': 'فشل في رفع الصورة. يرجى المحاولة مرة أخرى.',
  'imageUpload.change': 'تغيير',
  'imageUpload.remove': 'إزالة',
  'imageUpload.uploading': 'جاري الرفع...',
  'imageUpload.clickToUpload': 'انقر لرفع صورة',
  'imageUpload.dragDrop': 'أو اسحب وأفلت',
  'imageUpload.fileTypes': 'PNG، JPG، GIF حتى 10 ميجابايت',
  
  // Plant Search
  'plantSearch.searching': 'جاري البحث...',
  'plantSearch.found': 'تم العثور على معلومات النبات!',
  'plantSearch.notFound': 'لم يتم العثور على معلومات النبات',
  'plantSearch.error': 'فشل البحث. يرجى المحاولة مرة أخرى.',
  'plantSearch.autoFill': 'تعبئة تلقائية لمعلومات النبات',
  
  // Growth Tracking
  'growth.title': 'تتبع النمو',
  'growth.uploadProgress': 'رفع صورة التقدم',
  'growth.viewHistory': 'عرض تاريخ النمو',
  'growth.analysis': 'تحليل النمو بالذكاء الاصطناعي',
  'growth.stage': 'مرحلة النمو',
  'growth.healthScore': 'نقاط الصحة',
  'growth.growthRate': 'معدل النمو',
  'growth.recommendations': 'توصيات النمو',
};

interface TranslationContextType {
  language: 'en' | 'ar';
  t: (key: string) => string;
  toggleLanguage: () => void;
}

const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

export function TranslationProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<'en' | 'ar'>('en');

  const translations = language === 'ar' ? arabicTranslations : englishTranslations;

  const t = (key: string): string => {
    return translations[key] || key;
  };

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'ar' : 'en');
  };

  return (
    <TranslationContext.Provider value={{ language, t, toggleLanguage }}>
      <div className={language === 'ar' ? 'rtl' : 'ltr'} dir={language === 'ar' ? 'rtl' : 'ltr'}>
        {children}
      </div>
    </TranslationContext.Provider>
  );
}

export function useTranslation() {
  const context = useContext(TranslationContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  return context;
}
