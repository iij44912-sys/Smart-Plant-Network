import { useState, useEffect } from "react";
import { X, Leaf, Search, Loader } from "lucide-react";
import type { CreatePlant, PlantSearchResult } from "@/shared/types";
import { useTranslation } from "@/react-app/hooks/useTranslation";
import ImageUpload from "./ImageUpload";

interface AddPlantModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

export default function AddPlantModal({ onClose, onSuccess }: AddPlantModalProps) {
  const { t, language } = useTranslation();
  const [formData, setFormData] = useState<CreatePlant>({
    name: "",
    species: "",
    location: "",
    image_url: "",
    care_instructions: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [searchResult, setSearchResult] = useState<PlantSearchResult | null>(null);
  const [error, setError] = useState("");
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(null);

  const popularPlants = [
    { name: "Snake Plant", species: "Sansevieria trifasciata", emoji: "🐍" },
    { name: "Peace Lily", species: "Spathiphyllum", emoji: "🕊️" },
    { name: "Rubber Plant", species: "Ficus elastica", emoji: "🌿" },
    { name: "Monstera", species: "Monstera deliciosa", emoji: "🌱" },
    { name: "Pothos", species: "Epipremnum aureum", emoji: "💚" },
    { name: "Aloe Vera", species: "Aloe barbadensis", emoji: "🌵" },
  ];

  const sampleImages = [
    "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400",
    "https://images.unsplash.com/photo-1463320726281-696a485928c7?w=400",
    "https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=400",
    "https://images.unsplash.com/photo-1520302630591-6fbdc8b53bb8?w=400",
    "https://images.unsplash.com/photo-1509423350716-97f2360af8e4?w=400",
    "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400",
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError("");

    try {
      const response = await fetch("/api/plants", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          ...formData,
          species: formData.species || undefined,
          location: formData.location || undefined,
          image_url: formData.image_url || undefined,
          care_instructions: formData.care_instructions || undefined,
        }),
      });

      if (response.ok) {
        onSuccess();
      } else {
        const errorData = await response.json();
        setError(errorData.error || "Failed to add plant");
      }
    } catch (err) {
      setError("Network error. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Auto-search when plant name changes
  useEffect(() => {
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    if (formData.name.length > 2) {
      const timeout = setTimeout(() => {
        searchPlantInfo(formData.name);
      }, 1000);
      setSearchTimeout(timeout);
    } else {
      setSearchResult(null);
    }

    return () => {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    };
  }, [formData.name]);

  const searchPlantInfo = async (plantName: string) => {
    setIsSearching(true);
    setError("");
    
    try {
      const response = await fetch("/api/plants/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ plantName, language }),
      });

      if (response.ok) {
        const result: PlantSearchResult = await response.json();
        setSearchResult(result);
      } else {
        console.log("Plant search failed");
      }
    } catch (err) {
      console.error("Search error:", err);
    } finally {
      setIsSearching(false);
    }
  };

  const applySearchResult = () => {
    if (searchResult) {
      setFormData(prev => ({
        ...prev,
        species: searchResult.scientific_name,
        care_instructions: `${searchResult.care_instructions}\n\nLight: ${searchResult.light_requirements}\nWater: ${searchResult.water_requirements}\nTemperature: ${searchResult.temperature_range}\nHumidity: ${searchResult.humidity_requirements}`,
      }));
      setSearchResult(null);
    }
  };

  const selectPreset = (plant: typeof popularPlants[0]) => {
    setFormData(prev => ({
      ...prev,
      name: plant.name,
      species: plant.species,
    }));
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-3xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center">
              <Leaf className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">{t('addPlant.title')}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Quick Presets */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">{t('addPlant.popularPlants')}</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {popularPlants.map((plant, index) => (
              <button
                key={index}
                onClick={() => selectPreset(plant)}
                className="p-3 text-left border border-gray-200 rounded-xl hover:bg-green-50 hover:border-green-300 transition-all duration-200"
              >
                <div className="flex items-center space-x-2">
                  <span className="text-lg">{plant.emoji}</span>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{plant.name}</p>
                    <p className="text-xs text-gray-500">{plant.species}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Plant Name with Search */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('addPlant.name')} {t('addPlant.nameRequired')}
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                placeholder={t('addPlant.namePlaceholder')}
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                {isSearching ? (
                  <Loader className="w-5 h-5 text-gray-400 animate-spin" />
                ) : (
                  <Search className="w-5 h-5 text-gray-400" />
                )}
              </div>
            </div>
            
            {/* Search Result */}
            {searchResult && (
              <div className="mt-3 p-4 bg-green-50 border border-green-200 rounded-xl">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="text-sm font-semibold text-green-800 mb-1">
                      {t('plantSearch.found')}
                    </h4>
                    <p className="text-sm text-green-700 mb-2">
                      <strong>{searchResult.name}</strong> ({searchResult.scientific_name})
                    </p>
                    <p className="text-xs text-green-600 mb-2">
                      {searchResult.care_instructions.substring(0, 100)}...
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={applySearchResult}
                    className="ml-3 px-3 py-1 bg-green-600 text-white text-xs font-medium rounded-lg hover:bg-green-700 transition-colors"
                  >
                    {t('plantSearch.autoFill')}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Species */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('addPlant.species')}
            </label>
            <input
              type="text"
              value={formData.species}
              onChange={(e) => setFormData(prev => ({ ...prev, species: e.target.value }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
              placeholder={t('addPlant.speciesPlaceholder')}
            />
          </div>

          {/* Location */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('addPlant.location')}
            </label>
            <input
              type="text"
              value={formData.location}
              onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
              placeholder={t('addPlant.locationPlaceholder')}
            />
          </div>

          {/* Image Upload */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('addPlant.photo')}
            </label>
            <ImageUpload
              currentImage={formData.image_url}
              onImageUpload={(url) => setFormData(prev => ({ ...prev, image_url: url }))}
              className="mb-3"
            />
            
            {/* URL Input as Alternative */}
            <div className="mt-3">
              <input
                type="url"
                value={formData.image_url}
                onChange={(e) => setFormData(prev => ({ ...prev, image_url: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                placeholder={t('addPlant.photoPlaceholder')}
              />
            </div>
            
            {/* Sample Images */}
            <div className="mt-3">
              <p className="text-xs text-gray-500 mb-2">{t('addPlant.sampleImages')}</p>
              <div className="grid grid-cols-6 gap-2">
                {sampleImages.map((url, index) => (
                  <button
                    key={index}
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, image_url: url }))}
                    className={`aspect-square rounded-lg overflow-hidden border-2 transition-all duration-200 ${
                      formData.image_url === url ? 'border-green-500' : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <img
                      src={url}
                      alt={`Sample ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Care Instructions */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('addPlant.careInstructions')}
            </label>
            <textarea
              value={formData.care_instructions}
              onChange={(e) => setFormData(prev => ({ ...prev, care_instructions: e.target.value }))}
              rows={3}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 resize-none"
              placeholder={t('addPlant.carePlaceholder')}
            />
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-xl">
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          {/* Submit Buttons */}
          <div className="flex space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-all duration-200"
            >
              {t('addPlant.cancel')}
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !formData.name.trim()}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-medium rounded-xl hover:from-green-700 hover:to-emerald-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? t('addPlant.adding') : t('addPlant.add')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
