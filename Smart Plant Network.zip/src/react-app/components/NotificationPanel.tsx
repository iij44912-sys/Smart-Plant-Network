import { useState } from "react";
import { X, Bell, CheckCircle2, AlertTriangle, Clock, Droplets, Sun, Thermometer, Zap } from "lucide-react";
import type { AIRecommendation } from "@/shared/types";
import { useTranslation } from "@/react-app/hooks/useTranslation";

interface NotificationPanelProps {
  recommendations: (AIRecommendation & { plantName: string })[];
  onClose: () => void;
  onUpdate: () => void;
}

export default function NotificationPanel({ recommendations, onClose, onUpdate }: NotificationPanelProps) {
  const [acknowledging, setAcknowledging] = useState<number[]>([]);
  const { t } = useTranslation();

  const acknowledgeRecommendation = async (id: number) => {
    setAcknowledging(prev => [...prev, id]);
    
    try {
      await fetch(`/api/recommendations/${id}/acknowledge`, {
        method: "PUT",
        credentials: "include",
      });
      onUpdate();
    } catch (error) {
      console.error("Failed to acknowledge recommendation:", error);
    } finally {
      setAcknowledging(prev => prev.filter(i => i !== id));
    }
  };

  const getRecommendationIcon = (type: string) => {
    switch (type) {
      case 'watering': return <Droplets className="w-5 h-5" />;
      case 'lighting': return <Sun className="w-5 h-5" />;
      case 'temperature': return <Thermometer className="w-5 h-5" />;
      case 'fertilizing': return <Zap className="w-5 h-5" />;
      default: return <Bell className="w-5 h-5" />;
    }
  };

  const getPriorityStyle = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return {
          container: 'bg-red-50 border-red-200',
          icon: 'text-red-600',
          text: 'text-red-900',
          badge: 'bg-red-100 text-red-700',
          button: 'bg-red-100 hover:bg-red-200 text-red-700'
        };
      case 'high':
        return {
          container: 'bg-orange-50 border-orange-200',
          icon: 'text-orange-600',
          text: 'text-orange-900',
          badge: 'bg-orange-100 text-orange-700',
          button: 'bg-orange-100 hover:bg-orange-200 text-orange-700'
        };
      case 'medium':
        return {
          container: 'bg-yellow-50 border-yellow-200',
          icon: 'text-yellow-600',
          text: 'text-yellow-900',
          badge: 'bg-yellow-100 text-yellow-700',
          button: 'bg-yellow-100 hover:bg-yellow-200 text-yellow-700'
        };
      default:
        return {
          container: 'bg-blue-50 border-blue-200',
          icon: 'text-blue-600',
          text: 'text-blue-900',
          badge: 'bg-blue-100 text-blue-700',
          button: 'bg-blue-100 hover:bg-blue-200 text-blue-700'
        };
    }
  };

  const groupedRecommendations = recommendations.reduce((acc, rec) => {
    if (!acc[rec.priority]) acc[rec.priority] = [];
    acc[rec.priority].push(rec);
    return acc;
  }, {} as Record<string, typeof recommendations>);

  const priorityOrder = ['urgent', 'high', 'medium', 'low'];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-3xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center">
              <Bell className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">{t('notifications.title')}</h2>
              <p className="text-sm text-gray-600">
                {recommendations.length} {recommendations.length === 1 ? t('notifications.count') : t('notifications.countPlural')}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        {recommendations.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">{t('notifications.allCaughtUp')}</h3>
            <p className="text-gray-600">{t('notifications.noCare')}</p>
          </div>
        ) : (
          <div className="space-y-6">
            {priorityOrder.map(priority => {
              const recs = groupedRecommendations[priority];
              if (!recs?.length) return null;

              return (
                <div key={priority}>
                  <div className="flex items-center space-x-2 mb-3">
                    <AlertTriangle className={`w-4 h-4 ${
                      priority === 'urgent' ? 'text-red-500' :
                      priority === 'high' ? 'text-orange-500' :
                      priority === 'medium' ? 'text-yellow-500' :
                      'text-blue-500'
                    }`} />
                    <h3 className="font-semibold text-gray-900">
                      {t(`notifications.priority.${priority}`)}
                    </h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      priority === 'urgent' ? 'bg-red-100 text-red-700' :
                      priority === 'high' ? 'bg-orange-100 text-orange-700' :
                      priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-blue-100 text-blue-700'
                    }`}>
                      {recs.length}
                    </span>
                  </div>

                  <div className="space-y-3">
                    {recs.map((rec) => {
                      const style = getPriorityStyle(rec.priority);
                      const isAcknowledging = acknowledging.includes(rec.id);

                      return (
                        <div
                          key={rec.id}
                          className={`border rounded-2xl p-4 ${style.container}`}
                        >
                          <div className="flex items-start space-x-4">
                            <div className={`p-2 rounded-xl bg-white/50 ${style.icon}`}>
                              {getRecommendationIcon(rec.recommendation_type)}
                            </div>
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center space-x-2 mb-2">
                                <h4 className="font-semibold text-gray-900">
                                  {rec.plantName}
                                </h4>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${style.badge}`}>
                                  {rec.recommendation_type}
                                </span>
                              </div>
                              
                              <p className={`text-sm mb-3 ${style.text}`}>
                                {rec.message}
                              </p>
                              
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-1 text-xs text-gray-500">
                                  <Clock className="w-3 h-3" />
                                  <span>
                                    {new Date(rec.created_at).toLocaleString()}
                                  </span>
                                </div>
                                
                                <button
                                  onClick={() => acknowledgeRecommendation(rec.id)}
                                  disabled={isAcknowledging}
                                  className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors disabled:opacity-50 ${style.button}`}
                                >
                                  {isAcknowledging ? t('notifications.acknowledging') : t('notifications.markDone')}
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Footer */}
        {recommendations.length > 0 && (
          <div className="mt-8 pt-6 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-600">
                {t('notifications.footer')}
              </p>
              <button
                onClick={onClose}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium rounded-xl transition-colors"
              >
                {t('notifications.close')}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
