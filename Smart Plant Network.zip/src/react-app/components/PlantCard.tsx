import { useState } from "react";
import { Droplets, Sun, Thermometer, Wind, Clock, AlertTriangle, CheckCircle2, TrendingUp } from "lucide-react";
import type { PlantWithSensorData } from "@/shared/types";
import { useTranslation } from "@/react-app/hooks/useTranslation";
import PlantGrowthTracker from "./PlantGrowthTracker";

interface PlantCardProps {
  plant: PlantWithSensorData;
  onUpdate: () => void;
}

export default function PlantCard({ plant, onUpdate }: PlantCardProps) {
  const [isSimulating, setIsSimulating] = useState(false);
  const [showGrowthTracker, setShowGrowthTracker] = useState(false);
  const { t } = useTranslation();

  const simulateReading = async () => {
    setIsSimulating(true);
    try {
      await fetch(`/api/plants/${plant.id}/simulate-reading`, {
        method: "POST",
        credentials: "include",
      });
      onUpdate();
    } catch (error) {
      console.error("Failed to simulate reading:", error);
    } finally {
      setIsSimulating(false);
    }
  };

  const logCareAction = async (actionType: string) => {
    try {
      await fetch("/api/care-actions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          plant_id: plant.id,
          action_type: actionType,
        }),
      });
      onUpdate();
    } catch (error) {
      console.error("Failed to log care action:", error);
    }
  };

  const getHealthStatus = () => {
    const urgentRecs = plant.recommendations?.filter(r => r.priority === 'urgent') || [];
    const highRecs = plant.recommendations?.filter(r => r.priority === 'high') || [];
    
    if (urgentRecs.length > 0) return { status: 'urgent', color: 'red', text: t('plant.needsAttention') };
    if (highRecs.length > 0) return { status: 'warning', color: 'orange', text: t('plant.needsCare') };
    return { status: 'good', color: 'green', text: t('plant.healthy') };
  };

  const healthStatus = getHealthStatus();
  const reading = plant.latest_reading;

  return (
    <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-6 border border-green-200/50 shadow-lg hover:shadow-xl transition-all duration-300">
      {/* Plant Image and Header */}
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-emerald-500 rounded-2xl flex items-center justify-center">
            {plant.image_url ? (
              <img
                src={plant.image_url}
                alt={plant.name}
                className="w-16 h-16 rounded-2xl object-cover"
              />
            ) : (
              <span className="text-2xl">🌱</span>
            )}
          </div>
          
          <div>
            <h3 className="text-xl font-bold text-gray-900">{plant.name}</h3>
            {plant.species && (
              <p className="text-sm text-gray-600">{plant.species}</p>
            )}
            {plant.location && (
              <p className="text-xs text-gray-500">{plant.location}</p>
            )}
          </div>
        </div>

        {/* Health Status Badge */}
        <div className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
          healthStatus.color === 'red' ? 'bg-red-100 text-red-700' :
          healthStatus.color === 'orange' ? 'bg-orange-100 text-orange-700' :
          'bg-green-100 text-green-700'
        }`}>
          {healthStatus.color === 'green' ? (
            <CheckCircle2 className="w-3 h-3 mr-1" />
          ) : (
            <AlertTriangle className="w-3 h-3 mr-1" />
          )}
          {healthStatus.text}
        </div>
      </div>

      {/* Sensor Data */}
      {reading ? (
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-blue-50 rounded-xl p-3">
            <div className="flex items-center space-x-2 mb-1">
              <Droplets className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-700">{t('plant.soilMoisture')}</span>
            </div>
            <p className="text-lg font-bold text-blue-900">
              {reading.soil_moisture?.toFixed(1)}%
            </p>
          </div>

          <div className="bg-yellow-50 rounded-xl p-3">
            <div className="flex items-center space-x-2 mb-1">
              <Sun className="w-4 h-4 text-yellow-600" />
              <span className="text-sm font-medium text-yellow-700">{t('plant.light')}</span>
            </div>
            <p className="text-lg font-bold text-yellow-900">
              {reading.light_intensity?.toFixed(1)}%
            </p>
          </div>

          <div className="bg-red-50 rounded-xl p-3">
            <div className="flex items-center space-x-2 mb-1">
              <Thermometer className="w-4 h-4 text-red-600" />
              <span className="text-sm font-medium text-red-700">{t('plant.temperature')}</span>
            </div>
            <p className="text-lg font-bold text-red-900">
              {reading.temperature?.toFixed(1)}°C
            </p>
          </div>

          <div className="bg-green-50 rounded-xl p-3">
            <div className="flex items-center space-x-2 mb-1">
              <Wind className="w-4 h-4 text-green-600" />
              <span className="text-sm font-medium text-green-700">{t('plant.airQuality')}</span>
            </div>
            <p className="text-lg font-bold text-green-900">
              {reading.air_quality?.toFixed(1)}%
            </p>
          </div>
        </div>
      ) : (
        <div className="bg-gray-50 rounded-xl p-6 text-center mb-6">
          <p className="text-gray-600 mb-3">{t('plant.noData')}</p>
          <button
            onClick={simulateReading}
            disabled={isSimulating}
            className="text-sm text-green-600 hover:text-green-700 font-medium"
          >
            {isSimulating ? t('plant.generating') : t('plant.generateData')}
          </button>
        </div>
      )}

      {/* Recent Recommendations */}
      {plant.recommendations && plant.recommendations.length > 0 && (
        <div className="mb-6">
          <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center">
            <AlertTriangle className="w-4 h-4 mr-2 text-orange-500" />
            {t('plant.recommendations')}
          </h4>
          <div className="space-y-2">
            {plant.recommendations.slice(0, 2).map((rec) => (
              <div
                key={rec.id}
                className={`p-3 rounded-xl text-sm ${
                  rec.priority === 'urgent' ? 'bg-red-50 text-red-700 border border-red-200' :
                  rec.priority === 'high' ? 'bg-orange-50 text-orange-700 border border-orange-200' :
                  'bg-yellow-50 text-yellow-700 border border-yellow-200'
                }`}
              >
                {rec.message}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="flex space-x-2">
        <button
          onClick={() => logCareAction('watered')}
          className="flex-1 bg-blue-100 hover:bg-blue-200 text-blue-700 py-2 px-3 rounded-xl text-sm font-medium transition-colors flex items-center justify-center"
        >
          <Droplets className="w-4 h-4 mr-1" />
          {t('plant.watered')}
        </button>
        
        <button
          onClick={() => setShowGrowthTracker(!showGrowthTracker)}
          className="flex-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-700 py-2 px-3 rounded-xl text-sm font-medium transition-colors flex items-center justify-center"
        >
          <TrendingUp className="w-4 h-4 mr-1" />
          {t('growth.title')}
        </button>
        
        <button
          onClick={simulateReading}
          disabled={isSimulating}
          className="flex-1 bg-green-100 hover:bg-green-200 text-green-700 py-2 px-3 rounded-xl text-sm font-medium transition-colors flex items-center justify-center disabled:opacity-50"
        >
          <Clock className="w-4 h-4 mr-1" />
          {isSimulating ? "..." : t('plant.update')}
        </button>
      </div>

      {reading && (
        <p className="text-xs text-gray-500 mt-3 text-center">
          {t('plant.lastUpdated')}: {new Date(reading.created_at).toLocaleString()}
        </p>
      )}

      {/* Growth Tracker */}
      {showGrowthTracker && (
        <div className="mt-6">
          <PlantGrowthTracker plantId={plant.id} plantName={plant.name} />
        </div>
      )}
    </div>
  );
}
