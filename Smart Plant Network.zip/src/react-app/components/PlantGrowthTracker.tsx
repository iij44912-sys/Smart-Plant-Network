import { useState, useEffect } from "react";
import { TrendingUp, Camera, Calendar, BarChart3, Leaf, Star } from "lucide-react";
import { useTranslation } from "@/react-app/hooks/useTranslation";
import type { PlantGrowthAnalysis, PlantImage } from "@/shared/types";
import ImageUpload from "./ImageUpload";

interface PlantGrowthTrackerProps {
  plantId: number;
  plantName: string;
}

interface GrowthData {
  analysis: PlantGrowthAnalysis[];
  images: PlantImage[];
}

export default function PlantGrowthTracker({ plantId, plantName }: PlantGrowthTrackerProps) {
  const { t } = useTranslation();
  const [growthData, setGrowthData] = useState<GrowthData>({ analysis: [], images: [] });
  const [isLoading, setIsLoading] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showImageUpload, setShowImageUpload] = useState(false);

  useEffect(() => {
    fetchGrowthData();
  }, [plantId]);

  const fetchGrowthData = async () => {
    setIsLoading(true);
    try {
      const [analysisResponse, imagesResponse] = await Promise.all([
        fetch(`/api/plants/${plantId}/growth-analysis`, {
          credentials: "include",
        }),
        fetch(`/api/plants/${plantId}/images`, {
          credentials: "include",
        }),
      ]);

      const analysis = analysisResponse.ok ? await analysisResponse.json() : [];
      const images = imagesResponse.ok ? await imagesResponse.json() : [];

      setGrowthData({ analysis, images });
    } catch (error) {
      console.error("Failed to fetch growth data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageUpload = async (imageUrl: string) => {
    try {
      const response = await fetch(`/api/plants/${plantId}/images`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          plant_id: plantId,
          image_url: imageUrl,
          image_type: "progress",
          notes: `Growth progress photo - ${new Date().toLocaleDateString()}`,
        }),
      });

      if (response.ok) {
        await fetchGrowthData();
        setShowImageUpload(false);
      }
    } catch (error) {
      console.error("Failed to save image:", error);
    }
  };

  const analyzeGrowth = async () => {
    setIsAnalyzing(true);
    try {
      const response = await fetch(`/api/plants/${plantId}/analyze-growth`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
      });

      if (response.ok) {
        await fetchGrowthData();
      }
    } catch (error) {
      console.error("Failed to analyze growth:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const latestAnalysis = growthData.analysis[0];
  const progressImages = growthData.images.filter(img => img.image_type === 'progress');

  if (isLoading) {
    return (
      <div className="p-6 text-center">
        <div className="inline-block w-8 h-8 border-4 border-green-500 border-t-transparent rounded-full animate-spin" />
        <p className="mt-2 text-gray-600">{t('plant.generating')}</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900">{t('growth.title')}</h3>
            <p className="text-sm text-gray-600">{plantName}</p>
          </div>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => setShowImageUpload(true)}
            className="px-4 py-2 bg-gradient-to-r from-blue-500 to-indigo-600 text-white text-sm font-medium rounded-xl hover:from-blue-600 hover:to-indigo-700 transition-all duration-200 flex items-center space-x-2"
          >
            <Camera className="w-4 h-4" />
            <span>{t('growth.uploadProgress')}</span>
          </button>
          <button
            onClick={analyzeGrowth}
            disabled={isAnalyzing}
            className="px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-600 text-white text-sm font-medium rounded-xl hover:from-purple-600 hover:to-pink-700 transition-all duration-200 flex items-center space-x-2 disabled:opacity-50"
          >
            <BarChart3 className="w-4 h-4" />
            <span>{isAnalyzing ? t('plant.generating') : t('growth.analysis')}</span>
          </button>
        </div>
      </div>

      {/* Image Upload Modal */}
      {showImageUpload && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full">
            <h3 className="text-lg font-bold text-gray-900 mb-4">{t('growth.uploadProgress')}</h3>
            <ImageUpload
              onImageUpload={handleImageUpload}
              className="mb-4"
            />
            <div className="flex space-x-3">
              <button
                onClick={() => setShowImageUpload(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
              >
                {t('addPlant.cancel')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Latest Analysis */}
      {latestAnalysis && (
        <div className="mb-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200">
          <h4 className="text-sm font-semibold text-green-800 mb-3">{t('growth.analysis')}</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {latestAnalysis.growth_stage && (
              <div className="text-center">
                <Leaf className="w-6 h-6 text-green-600 mx-auto mb-1" />
                <p className="text-xs text-gray-600">{t('growth.stage')}</p>
                <p className="text-sm font-semibold text-gray-900">{latestAnalysis.growth_stage}</p>
              </div>
            )}
            {latestAnalysis.health_score && (
              <div className="text-center">
                <Star className="w-6 h-6 text-yellow-500 mx-auto mb-1" />
                <p className="text-xs text-gray-600">{t('growth.healthScore')}</p>
                <p className="text-sm font-semibold text-gray-900">{latestAnalysis.health_score}/100</p>
              </div>
            )}
            {latestAnalysis.growth_rate && (
              <div className="text-center">
                <TrendingUp className="w-6 h-6 text-blue-600 mx-auto mb-1" />
                <p className="text-xs text-gray-600">{t('growth.growthRate')}</p>
                <p className="text-sm font-semibold text-gray-900">{latestAnalysis.growth_rate} cm/week</p>
              </div>
            )}
            <div className="text-center">
              <Calendar className="w-6 h-6 text-purple-600 mx-auto mb-1" />
              <p className="text-xs text-gray-600">{t('plant.lastUpdated')}</p>
              <p className="text-sm font-semibold text-gray-900">
                {new Date(latestAnalysis.analysis_date).toLocaleDateString()}
              </p>
            </div>
          </div>
          {latestAnalysis.recommendations && (
            <div className="mt-4 p-3 bg-white/80 rounded-lg">
              <p className="text-xs font-medium text-gray-600 mb-1">{t('growth.recommendations')}</p>
              <p className="text-sm text-gray-800">{latestAnalysis.recommendations}</p>
            </div>
          )}
        </div>
      )}

      {/* Progress Images Timeline */}
      {progressImages.length > 0 && (
        <div className="mb-6">
          <h4 className="text-sm font-semibold text-gray-700 mb-3">{t('growth.viewHistory')}</h4>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {progressImages.slice(0, 8).map((image, index) => (
              <div key={image.id} className="relative group">
                <img
                  src={image.image_url}
                  alt={`Progress ${index + 1}`}
                  className="w-full aspect-square object-cover rounded-lg border border-gray-200"
                />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                  <p className="text-white text-xs font-medium text-center px-2">
                    {new Date(image.created_at).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
          {progressImages.length > 8 && (
            <p className="text-xs text-gray-500 mt-2 text-center">
              +{progressImages.length - 8} more photos
            </p>
          )}
        </div>
      )}

      {/* Analysis History */}
      {growthData.analysis.length > 1 && (
        <div>
          <h4 className="text-sm font-semibold text-gray-700 mb-3">Analysis History</h4>
          <div className="space-y-3 max-h-48 overflow-y-auto">
            {growthData.analysis.slice(1, 6).map((analysis) => (
              <div key={analysis.id} className="p-3 bg-gray-50 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-xs font-medium text-gray-600">
                    {new Date(analysis.analysis_date).toLocaleDateString()}
                  </span>
                  {analysis.health_score && (
                    <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                      {analysis.health_score}/100
                    </span>
                  )}
                </div>
                {analysis.ai_analysis && (
                  <p className="text-xs text-gray-700">{analysis.ai_analysis.substring(0, 120)}...</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty State */}
      {progressImages.length === 0 && !latestAnalysis && (
        <div className="text-center py-8">
          <TrendingUp className="w-12 h-12 text-gray-400 mx-auto mb-3" />
          <h4 className="text-lg font-medium text-gray-900 mb-2">Start Tracking Growth</h4>
          <p className="text-gray-600 mb-4">
            Upload progress photos and get AI-powered growth analysis for your {plantName}.
          </p>
          <button
            onClick={() => setShowImageUpload(true)}
            className="px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-medium rounded-xl hover:from-green-700 hover:to-emerald-700 transition-all duration-200"
          >
            {t('growth.uploadProgress')}
          </button>
        </div>
      )}
    </div>
  );
}
