import { useState, useRef } from "react";
import { Camera, Upload, X } from "lucide-react";
import { useTranslation } from "@/react-app/hooks/useTranslation";

interface ImageUploadProps {
  onImageUpload: (imageUrl: string) => void;
  currentImage?: string;
  className?: string;
}

export default function ImageUpload({ onImageUpload, currentImage, className = "" }: ImageUploadProps) {
  const { t } = useTranslation();
  const [isUploading, setIsUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert(t('imageUpload.invalidType'));
      return;
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      alert(t('imageUpload.sizeTooLarge'));
      return;
    }

    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append('image', file);

      const response = await fetch('/api/upload-image', {
        method: 'POST',
        credentials: 'include',
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        onImageUpload(data.url);
      } else {
        alert(t('imageUpload.uploadFailed'));
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert(t('imageUpload.uploadFailed'));
    } finally {
      setIsUploading(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const openFileDialog = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className={`relative ${className}`}>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileInputChange}
        className="hidden"
      />

      {currentImage ? (
        <div className="relative group">
          <img
            src={currentImage}
            alt="Plant"
            className="w-full h-48 object-cover rounded-xl"
          />
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-200 rounded-xl flex items-center justify-center space-x-2">
            <button
              onClick={openFileDialog}
              disabled={isUploading}
              className="px-3 py-2 bg-white/90 text-gray-800 rounded-lg text-sm font-medium hover:bg-white transition-colors"
            >
              <Camera className="w-4 h-4 inline mr-1" />
              {t('imageUpload.change')}
            </button>
            <button
              onClick={() => onImageUpload('')}
              className="px-3 py-2 bg-red-500/90 text-white rounded-lg text-sm font-medium hover:bg-red-500 transition-colors"
            >
              <X className="w-4 h-4 inline mr-1" />
              {t('imageUpload.remove')}
            </button>
          </div>
        </div>
      ) : (
        <div
          onClick={openFileDialog}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-200 ${
            dragActive
              ? 'border-green-500 bg-green-50'
              : 'border-gray-300 hover:border-gray-400 hover:bg-gray-50'
          } ${isUploading ? 'pointer-events-none opacity-50' : ''}`}
        >
          <div className="flex flex-col items-center space-y-3">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
              {isUploading ? (
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Upload className="w-6 h-6 text-white" />
              )}
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900">
                {isUploading ? t('imageUpload.uploading') : t('imageUpload.clickToUpload')}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                {t('imageUpload.dragDrop')}
              </p>
              <p className="text-xs text-gray-400 mt-1">
                {t('imageUpload.fileTypes')}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
