import z from "zod";

// Plant schema and types
export const PlantSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  name: z.string(),
  species: z.string().optional(),
  location: z.string().optional(),
  image_url: z.string().optional(),
  care_instructions: z.string().optional(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreatePlantSchema = z.object({
  name: z.string().min(1, "Plant name is required"),
  species: z.string().optional(),
  location: z.string().optional(),
  image_url: z.string().url().optional(),
  care_instructions: z.string().optional(),
});

export type Plant = z.infer<typeof PlantSchema>;
export type CreatePlant = z.infer<typeof CreatePlantSchema>;

// Sensor reading schema and types
export const SensorReadingSchema = z.object({
  id: z.number(),
  plant_id: z.number(),
  soil_moisture: z.number().optional(),
  temperature: z.number().optional(),
  light_intensity: z.number().optional(),
  air_quality: z.number().optional(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type SensorReading = z.infer<typeof SensorReadingSchema>;

// Care action schema and types
export const CareActionSchema = z.object({
  id: z.number(),
  plant_id: z.number(),
  user_id: z.string(),
  action_type: z.enum(['watered', 'fertilized', 'pruned', 'moved']),
  notes: z.string().optional(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateCareActionSchema = z.object({
  plant_id: z.number(),
  action_type: z.enum(['watered', 'fertilized', 'pruned', 'moved']),
  notes: z.string().optional(),
});

export type CareAction = z.infer<typeof CareActionSchema>;
export type CreateCareAction = z.infer<typeof CreateCareActionSchema>;

// AI recommendation schema and types
export const AIRecommendationSchema = z.object({
  id: z.number(),
  plant_id: z.number(),
  recommendation_type: z.enum(['watering', 'lighting', 'temperature', 'fertilizing']),
  message: z.string(),
  priority: z.enum(['low', 'medium', 'high', 'urgent']),
  is_acknowledged: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type AIRecommendation = z.infer<typeof AIRecommendationSchema>;

// Plant with latest sensor data
export type PlantWithSensorData = Plant & {
  latest_reading?: SensorReading;
  recommendations?: AIRecommendation[];
};

// Plant search result schema
export const PlantSearchResultSchema = z.object({
  name: z.string(),
  scientific_name: z.string(),
  common_names: z.array(z.string()),
  care_instructions: z.string(),
  light_requirements: z.string(),
  water_requirements: z.string(),
  temperature_range: z.string(),
  humidity_requirements: z.string(),
  growth_stage: z.string(),
  image_url: z.string().optional(),
});

export type PlantSearchResult = z.infer<typeof PlantSearchResultSchema>;

// Plant image schema
export const PlantImageSchema = z.object({
  id: z.number(),
  plant_id: z.number(),
  user_id: z.string(),
  image_url: z.string(),
  image_type: z.enum(['progress', 'care', 'general']),
  notes: z.string().optional(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreatePlantImageSchema = z.object({
  plant_id: z.number(),
  image_url: z.string().url(),
  image_type: z.enum(['progress', 'care', 'general']),
  notes: z.string().optional(),
});

export type PlantImage = z.infer<typeof PlantImageSchema>;
export type CreatePlantImage = z.infer<typeof CreatePlantImageSchema>;

// Plant growth analysis schema
export const PlantGrowthAnalysisSchema = z.object({
  id: z.number(),
  plant_id: z.number(),
  analysis_date: z.string(),
  growth_stage: z.string().optional(),
  health_score: z.number().optional(),
  growth_rate: z.number().optional(),
  recommendations: z.string().optional(),
  ai_analysis: z.string().optional(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type PlantGrowthAnalysis = z.infer<typeof PlantGrowthAnalysisSchema>;
