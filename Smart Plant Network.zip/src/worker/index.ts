import { Hono } from "hono";

interface EnvWithSecrets {
  MOCHA_USERS_SERVICE_API_URL: string;
  MOCHA_USERS_SERVICE_API_KEY: string;
  OPENAI_API_KEY: string;
  R2_BUCKET: R2Bucket;
  DB: D1Database;
}
import { cors } from "hono/cors";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import { getCookie, setCookie } from "hono/cookie";
import {
  CreatePlantSchema,
  CreateCareActionSchema,
  CreatePlantImageSchema,
  type Plant,
  type SensorReading,
  type AIRecommendation,
  type PlantWithSensorData,
  type PlantSearchResult,
} from "@/shared/types";
import OpenAI from "openai";

const app = new Hono<{ Bindings: EnvWithSecrets }>();

app.use("*", cors({
  origin: "*",
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowHeaders: ["Content-Type", "Authorization"],
  credentials: true,
}));

// Auth routes
app.get('/api/oauth/google/redirect_url', async (c) => {
  const redirectUrl = await getOAuthRedirectUrl('google', {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Plants routes
app.get("/api/plants", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  
  const { results: plants } = await c.env.DB.prepare(
    "SELECT * FROM plants WHERE user_id = ? ORDER BY created_at DESC"
  ).bind(user.id).all();

  const plantsWithData: PlantWithSensorData[] = [];

  for (const plant of plants) {
    const { results: readings } = await c.env.DB.prepare(
      "SELECT * FROM sensor_readings WHERE plant_id = ? ORDER BY created_at DESC LIMIT 1"
    ).bind(plant.id).all();

    const { results: recommendations } = await c.env.DB.prepare(
      "SELECT * FROM ai_recommendations WHERE plant_id = ? AND is_acknowledged = FALSE ORDER BY priority DESC, created_at DESC"
    ).bind(plant.id).all();

    plantsWithData.push({
      ...plant as Plant,
      latest_reading: readings[0] as SensorReading | undefined,
      recommendations: recommendations as AIRecommendation[],
    });
  }

  return c.json(plantsWithData);
});

app.post("/api/plants", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const body = await c.req.json();
  
  const validation = CreatePlantSchema.safeParse(body);
  if (!validation.success) {
    return c.json({ error: "Invalid plant data", details: validation.error }, 400);
  }

  const { name, species, location, image_url, care_instructions } = validation.data;

  const result = await c.env.DB.prepare(
    `INSERT INTO plants (user_id, name, species, location, image_url, care_instructions, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
  ).bind(user.id, name, species || null, location || null, image_url || null, care_instructions || null).run();

  const plant = await c.env.DB.prepare(
    "SELECT * FROM plants WHERE id = ?"
  ).bind(result.meta.last_row_id).first();

  return c.json(plant, 201);
});

// Sensor readings routes
app.get("/api/plants/:plantId/readings", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const plantId = c.req.param("plantId");

  // Verify plant belongs to user
  const plant = await c.env.DB.prepare(
    "SELECT * FROM plants WHERE id = ? AND user_id = ?"
  ).bind(plantId, user.id).first();

  if (!plant) {
    return c.json({ error: "Plant not found" }, 404);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM sensor_readings WHERE plant_id = ? ORDER BY created_at DESC LIMIT 100"
  ).bind(plantId).all();

  return c.json(results);
});

// Care actions routes
app.post("/api/care-actions", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const body = await c.req.json();
  
  const validation = CreateCareActionSchema.safeParse(body);
  if (!validation.success) {
    return c.json({ error: "Invalid care action data", details: validation.error }, 400);
  }

  const { plant_id, action_type, notes } = validation.data;

  // Verify plant belongs to user
  const plant = await c.env.DB.prepare(
    "SELECT * FROM plants WHERE id = ? AND user_id = ?"
  ).bind(plant_id, user.id).first();

  if (!plant) {
    return c.json({ error: "Plant not found" }, 404);
  }

  const result = await c.env.DB.prepare(
    `INSERT INTO care_actions (plant_id, user_id, action_type, notes, created_at, updated_at)
     VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))`
  ).bind(plant_id, user.id, action_type, notes || null).run();

  const careAction = await c.env.DB.prepare(
    "SELECT * FROM care_actions WHERE id = ?"
  ).bind(result.meta.last_row_id).first();

  return c.json(careAction, 201);
});

// AI recommendations routes
app.put("/api/recommendations/:id/acknowledge", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const recommendationId = c.req.param("id");

  // Verify recommendation belongs to user's plant
  const recommendation = await c.env.DB.prepare(
    `SELECT r.* FROM ai_recommendations r
     JOIN plants p ON r.plant_id = p.id
     WHERE r.id = ? AND p.user_id = ?`
  ).bind(recommendationId, user.id).first();

  if (!recommendation) {
    return c.json({ error: "Recommendation not found" }, 404);
  }

  await c.env.DB.prepare(
    "UPDATE ai_recommendations SET is_acknowledged = TRUE, updated_at = datetime('now') WHERE id = ?"
  ).bind(recommendationId).run();

  return c.json({ success: true });
});

// Simulate sensor data endpoint (for demo purposes)
app.post("/api/plants/:plantId/simulate-reading", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const plantId = c.req.param("plantId");

  // Verify plant belongs to user
  const plant = await c.env.DB.prepare(
    "SELECT * FROM plants WHERE id = ? AND user_id = ?"
  ).bind(plantId, user.id).first();

  if (!plant) {
    return c.json({ error: "Plant not found" }, 404);
  }

  // Generate simulated sensor data
  const soilMoisture = Math.random() * 100;
  const temperature = 18 + Math.random() * 12; // 18-30°C
  const lightIntensity = Math.random() * 100;
  const airQuality = 50 + Math.random() * 50; // 50-100%

  // Insert sensor reading
  await c.env.DB.prepare(
    `INSERT INTO sensor_readings (plant_id, soil_moisture, temperature, light_intensity, air_quality, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
  ).bind(plantId, soilMoisture, temperature, lightIntensity, airQuality).run();

  // Generate AI recommendations based on readings
  const recommendations = [];

  if (soilMoisture < 30) {
    recommendations.push({
      recommendation_type: 'watering',
      message: `Your ${plant.name} needs water! Soil moisture is at ${soilMoisture.toFixed(1)}%.`,
      priority: soilMoisture < 15 ? 'urgent' : 'high'
    });
  }

  if (lightIntensity < 20) {
    recommendations.push({
      recommendation_type: 'lighting',
      message: `${plant.name} needs more light. Consider moving it closer to a window.`,
      priority: 'medium'
    });
  }

  if (temperature > 28) {
    recommendations.push({
      recommendation_type: 'temperature',
      message: `It's getting warm for ${plant.name}. Consider moving it to a cooler spot.`,
      priority: 'medium'
    });
  }

  // Insert recommendations
  for (const rec of recommendations) {
    await c.env.DB.prepare(
      `INSERT INTO ai_recommendations (plant_id, recommendation_type, message, priority, is_acknowledged, created_at, updated_at)
       VALUES (?, ?, ?, ?, FALSE, datetime('now'), datetime('now'))`
    ).bind(plantId, rec.recommendation_type, rec.message, rec.priority).run();
  }

  return c.json({ success: true, recommendations: recommendations.length });
});

// Plant search endpoint using OpenAI
app.post("/api/plants/search", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  
  const body = await c.req.json();
  const { plantName, language = 'en' } = body;
  
  if (!plantName) {
    return c.json({ error: "Plant name is required" }, 400);
  }

  try {
    const openai = new OpenAI({
      apiKey: c.env.OPENAI_API_KEY,
    });

    const prompt = language === 'ar' 
      ? `أنت خبير في النباتات. أعطني معلومات مفصلة عن النبات "${plantName}" باللغة العربية. يجب أن تتضمن المعلومات:
- الاسم العلمي
- الأسماء الشائعة
- تعليمات الرعاية
- متطلبات الضوء
- متطلبات الماء
- نطاق درجة الحرارة المناسب
- متطلبات الرطوبة
- مرحلة النمو الحالية المتوقعة
قدم الإجابة بتنسيق JSON فقط.`
      : `You are a plant expert. Give me detailed information about the plant "${plantName}" in English. Include:
- Scientific name
- Common names
- Care instructions
- Light requirements
- Water requirements
- Temperature range
- Humidity requirements
- Current expected growth stage
Provide the answer in JSON format only.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are a helpful plant care expert. Always respond with valid JSON data."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    const plantInfo = JSON.parse(response.choices[0].message.content || '{}');
    
    return c.json({
      name: plantInfo.name || plantName,
      scientific_name: plantInfo.scientific_name || '',
      common_names: plantInfo.common_names || [],
      care_instructions: plantInfo.care_instructions || '',
      light_requirements: plantInfo.light_requirements || '',
      water_requirements: plantInfo.water_requirements || '',
      temperature_range: plantInfo.temperature_range || '',
      humidity_requirements: plantInfo.humidity_requirements || '',
      growth_stage: plantInfo.growth_stage || '',
    } as PlantSearchResult);

  } catch (error) {
    console.error('Plant search error:', error);
    return c.json({ error: "Failed to search plant information" }, 500);
  }
});

// Image upload endpoint
app.post("/api/upload-image", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);

  try {
    const formData = await c.req.formData();
    const file = formData.get('image') as File;

    if (!file) {
      return c.json({ error: "No image file provided" }, 400);
    }

    // Generate unique filename
    const timestamp = Date.now();
    const extension = file.name.split('.').pop() || 'jpg';
    const fileName = `plants/${user.id}/${timestamp}.${extension}`;

    // Upload to R2
    await c.env.R2_BUCKET.put(fileName, file.stream(), {
      httpMetadata: {
        contentType: file.type,
      },
    });

    // Generate public URL
    const imageUrl = `https://your-r2-domain.com/${fileName}`;

    return c.json({ url: imageUrl });
  } catch (error) {
    console.error('Image upload error:', error);
    return c.json({ error: "Failed to upload image" }, 500);
  }
});

// Plant images routes
app.post("/api/plants/:plantId/images", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const plantId = c.req.param("plantId");
  const body = await c.req.json();
  
  const validation = CreatePlantImageSchema.safeParse(body);
  if (!validation.success) {
    return c.json({ error: "Invalid image data", details: validation.error }, 400);
  }

  // Verify plant belongs to user
  const plant = await c.env.DB.prepare(
    "SELECT * FROM plants WHERE id = ? AND user_id = ?"
  ).bind(plantId, user.id).first();

  if (!plant) {
    return c.json({ error: "Plant not found" }, 404);
  }

  const { image_url, image_type, notes } = validation.data;

  const result = await c.env.DB.prepare(
    `INSERT INTO plant_images (plant_id, user_id, image_url, image_type, notes, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
  ).bind(plantId, user.id, image_url, image_type, notes || null).run();

  const plantImage = await c.env.DB.prepare(
    "SELECT * FROM plant_images WHERE id = ?"
  ).bind(result.meta.last_row_id).first();

  return c.json(plantImage, 201);
});

// Get plant images
app.get("/api/plants/:plantId/images", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const plantId = c.req.param("plantId");

  // Verify plant belongs to user
  const plant = await c.env.DB.prepare(
    "SELECT * FROM plants WHERE id = ? AND user_id = ?"
  ).bind(plantId, user.id).first();

  if (!plant) {
    return c.json({ error: "Plant not found" }, 404);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM plant_images WHERE plant_id = ? ORDER BY created_at DESC"
  ).bind(plantId).all();

  return c.json(results);
});

// AI Growth Analysis endpoint
app.post("/api/plants/:plantId/analyze-growth", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const plantId = c.req.param("plantId");

  // Verify plant belongs to user
  const plant = await c.env.DB.prepare(
    "SELECT * FROM plants WHERE id = ? AND user_id = ?"
  ).bind(plantId, user.id).first();

  if (!plant) {
    return c.json({ error: "Plant not found" }, 404);
  }

  try {
    // Get recent images for analysis
    const { results: images } = await c.env.DB.prepare(
      "SELECT * FROM plant_images WHERE plant_id = ? AND image_type = 'progress' ORDER BY created_at DESC LIMIT 5"
    ).bind(plantId).all();

    // Get latest sensor data
    const { results: readings } = await c.env.DB.prepare(
      "SELECT * FROM sensor_readings WHERE plant_id = ? ORDER BY created_at DESC LIMIT 10"
    ).bind(plantId).all();

    const openai = new OpenAI({
      apiKey: c.env.OPENAI_API_KEY,
    });

    const analysisPrompt = `Analyze the growth progress of this plant: ${plant.name} (${plant.species || 'unknown species'}).

Recent care information:
- ${plant.care_instructions || 'No specific care instructions provided'}

Recent sensor readings:
${readings.map(r => `- Soil Moisture: ${r.soil_moisture}%, Temperature: ${r.temperature}°C, Light: ${r.light_intensity}%, Air Quality: ${r.air_quality}%`).join('\n')}

Number of progress photos available: ${images.length}

Provide an AI analysis including:
1. Estimated growth stage (seedling, young, mature, flowering)
2. Health score (0-100)
3. Estimated growth rate (cm per week)
4. Growth recommendations
5. Overall assessment

Respond in JSON format with these exact keys: growth_stage, health_score, growth_rate, recommendations, ai_analysis`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are an AI plant growth analyst. Provide detailed scientific analysis based on available data."
        },
        {
          role: "user",
          content: analysisPrompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    const analysis = JSON.parse(response.choices[0].message.content || '{}');

    // Store the analysis
    const result = await c.env.DB.prepare(
      `INSERT INTO plant_growth_analysis (plant_id, analysis_date, growth_stage, health_score, growth_rate, recommendations, ai_analysis, created_at, updated_at)
       VALUES (?, date('now'), ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).bind(
      plantId,
      analysis.growth_stage || null,
      analysis.health_score || null,
      analysis.growth_rate || null,
      analysis.recommendations || null,
      analysis.ai_analysis || null
    ).run();

    const savedAnalysis = await c.env.DB.prepare(
      "SELECT * FROM plant_growth_analysis WHERE id = ?"
    ).bind(result.meta.last_row_id).first();

    return c.json(savedAnalysis);
  } catch (error) {
    console.error('Growth analysis error:', error);
    return c.json({ error: "Failed to analyze plant growth" }, 500);
  }
});

// Get growth analysis history
app.get("/api/plants/:plantId/growth-analysis", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ error: "Unauthorized" }, 401);
  const plantId = c.req.param("plantId");

  // Verify plant belongs to user
  const plant = await c.env.DB.prepare(
    "SELECT * FROM plants WHERE id = ? AND user_id = ?"
  ).bind(plantId, user.id).first();

  if (!plant) {
    return c.json({ error: "Plant not found" }, 404);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM plant_growth_analysis WHERE plant_id = ? ORDER BY analysis_date DESC"
  ).bind(plantId).all();

  return c.json(results);
});

export default app;
